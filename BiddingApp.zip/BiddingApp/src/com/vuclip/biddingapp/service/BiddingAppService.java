package com.vuclip.biddingapp.service;

import java.util.List;

import com.vuclip.biddingapp.model.BididingDetails;
import com.vuclip.biddingapp.model.Item;

public interface BiddingAppService {
	
	public List<BididingDetails> getAllBids(Item item);
 
	public boolean addBid(BididingDetails bid);
	
	public BididingDetails getWinningBid(Item item, BiddingStrategy startegy);
}
