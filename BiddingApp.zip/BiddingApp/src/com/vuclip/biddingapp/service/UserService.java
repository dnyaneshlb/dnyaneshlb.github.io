package com.vuclip.biddingapp.service;



import java.util.List;

import com.vuclip.biddingapp.model.BididingDetails;
import com.vuclip.biddingapp.model.Item;

public interface UserService {
	public void bid(Item item);
	
	public BididingDetails getWinningBid(Item item);
	
	public List<BididingDetails> getAllBids(Item item);
}
