package com.vuclip.biddingapp.service;

import java.time.Instant;
import java.util.List;

import com.vuclip.biddingapp.model.BididingDetails;
import com.vuclip.biddingapp.model.Item;
import com.vuclip.biddingapp.model.User;

public class UserServiceImpl implements UserService{

	private User user;
	
	
	private BiddingAppService biddingService;
	
	private BiddingStrategy strategy;
	
	
	@Override
	public BididingDetails getWinningBid(Item item) {
		BididingDetails winningBid = biddingService.getWinningBid(item, this.strategy);
		return winningBid;
	}

	
	/*
	 * This returns all bids for given item 
	 */
	@Override
	public List<BididingDetails> getAllBids(Item item) {
		return biddingService.getAllBids(item);
	}
	
	

	@Override
	public void bid(Item item) {
		/*
		 * Code to create a get current user and item details'
		 * 
		 * Construct a BiddingDetails object
		 * 
		 * User BiddingAppService and call bid
		 */
		
		biddingService.addBid(constructBiddingDetailsObject(item));
	}

	
	/*
	 * 
	 */
	private BididingDetails constructBiddingDetailsObject(Item item) {
		BididingDetails bidDetails1 = new BididingDetails();
		bidDetails1.setItemId(item.getItemId());
		bidDetails1.setTime(Instant.now());
		bidDetails1.setUserId(this.user.getUserId());
		return bidDetails1;
	}

	
	
	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}

	public BiddingAppService getBiddingService() {
		return biddingService;
	}

	public void setBiddingService(BiddingAppService biddingService) {
		this.biddingService = biddingService;
	}


	public BiddingStrategy getStrategy() {
		return strategy;
	}


	public void setStrategy(BiddingStrategy strategy) {
		this.strategy = strategy;
	}

}
