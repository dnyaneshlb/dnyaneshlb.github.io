package com.vuclip.biddingapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.vuclip.biddingapp.data.AppData;
import com.vuclip.biddingapp.model.BididingDetails;
import com.vuclip.biddingapp.model.Item;

public class BiddingAppServiceImpl implements BiddingAppService{
	
	@Override
	public List<BididingDetails> getAllBids(Item item) {
		List<BididingDetails> allItembids = new ArrayList<>();
		for(Map.Entry<Integer, BididingDetails> map : AppData.bids.entrySet()){
			int itemId = map.getValue().getItemId();
			if(item.getItemId() == itemId){
				allItembids.add(map.getValue());
			}
		}
		return allItembids;
	}

	@Override
	public boolean addBid(BididingDetails bid) {
		AppData.bids.put(bid.getBiddingId(), bid);
		return true;
	}

	@Override
	public BididingDetails getWinningBid(Item item, BiddingStrategy strategy) {
		return strategy.bid(AppData.bids, item);
	}

}
