package com.vuclip.biddingapp.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.vuclip.biddingapp.model.BididingDetails;
import com.vuclip.biddingapp.model.Item;

public class TimeBasedBiddingStrategy implements BiddingStrategy{

	@Override
	public BididingDetails bid(Map<Integer, BididingDetails>bids, Item item) {
		List<BididingDetails> allBidsForItem = bids.values()
				.stream()
				.filter(node -> node.getItemId() == item.getItemId())
				.collect(Collectors.toList());
		
		BididingDetails b = null;
		
		for(BididingDetails bid : allBidsForItem){
			//code to find the user that last bidded for this item
		}
		
		return b;
	}

}
