package com.vuclip.biddingapp.service;

import java.util.Map;

import com.vuclip.biddingapp.model.BididingDetails;
import com.vuclip.biddingapp.model.Item;

public interface BiddingStrategy {

	public BididingDetails bid(Map<Integer, BididingDetails>bids, Item item);
}
