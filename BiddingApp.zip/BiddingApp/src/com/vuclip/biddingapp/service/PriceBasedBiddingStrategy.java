package com.vuclip.biddingapp.service;

import java.util.Map;

import com.vuclip.biddingapp.model.BididingDetails;
import com.vuclip.biddingapp.model.Item;

public class PriceBasedBiddingStrategy implements BiddingStrategy{

	public BididingDetails bid(Map<Integer, BididingDetails>bids, Item item) {
		return null;
		
	}


}
	