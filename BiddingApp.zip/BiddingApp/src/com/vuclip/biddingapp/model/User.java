package com.vuclip.biddingapp.model;

public class User {
	private int userId;
	
	private String userName;
	
	private long userContactNumber;

	public User(int userId, String userName, long userContactNumber) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userContactNumber = userContactNumber;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getUserContactNumber() {
		return userContactNumber;
	}

	public void setUserContactNumber(long userContactNumber) {
		this.userContactNumber = userContactNumber;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userContactNumber=" + userContactNumber
				+ "]";
	}

}
