package com.vuclip.biddingapp.model;

import java.time.Instant;

public class BididingDetails {
	private int biddingId;
	
	private int userId;
	
	private int itemId;
	
	private Instant time;

	public Instant getTime() {
		return time;
	}

	public void setTime(Instant time) {
		this.time = time;
	}

	public BididingDetails(int biddingId, int userId, int itemId) {
		super();
		this.biddingId = biddingId;
		this.userId = userId;
		this.itemId = itemId;
	}

	public BididingDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getBiddingId() {
		return biddingId;
	}

	public void setBiddingId(int biddingId) {
		this.biddingId = biddingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	@Override
	public String toString() {
		return "BididingDetails [biddingId=" + biddingId + ", userId=" + userId + ", itemId=" + itemId + "]";
	}

}
