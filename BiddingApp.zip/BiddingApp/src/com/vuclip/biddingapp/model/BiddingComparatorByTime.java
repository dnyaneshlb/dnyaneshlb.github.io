package com.vuclip.biddingapp.model;

import java.util.Comparator;

public class BiddingComparatorByTime implements Comparator<BididingDetails> {

	@Override
	public int compare(BididingDetails o1, BididingDetails o2) {
		if(o1 != null && o2 != null){
			return o1.getTime().compareTo(o2.getTime());
		}
		return 1;
	}
	
}
