package com.vuclip.biddingapp;

import com.vuclip.biddingapp.data.AppData;
import com.vuclip.biddingapp.model.User;
import com.vuclip.biddingapp.service.TimeBasedBiddingStrategy;
import com.vuclip.biddingapp.service.UserServiceImpl;

public class BiddingMain {
	public static void main(String[] args) {
		AppData.bootstrap();
		
		UserServiceImpl userService = new UserServiceImpl();
		
		User newUser = new User(3, "A",24234);
		userService.setUser(newUser);
		userService.setStrategy(new TimeBasedBiddingStrategy());
		userService.bid(AppData.item1);
	}
}
