package com.vuclip.biddingapp.data;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import com.vuclip.biddingapp.model.BididingDetails;
import com.vuclip.biddingapp.model.Item;
import com.vuclip.biddingapp.model.User;

public class AppData {
	public static User user1 = new User(1, "Dnyanesh", 234234);
	
	public static User user2 = new User(2, "Ajit", 234234);
	
	public static User user3 = new User(3, "Sujit", 234234);
	
	public static Item item1 = new Item(1, "Laptop1", "1", 100);
	public static Item item2 = new Item(1, "Laptop2", "2", 101);
	public 	static Item item3 = new Item(1, "Laptop3", "3", 102);
	
	
	public static Map<Integer,BididingDetails> bids = new HashMap<>();
	
	
	public static void bootstrap(){
		BididingDetails bid1 = new BididingDetails();
		bid1.setBiddingId(1);
		bid1.setTime(Instant.now());
		bid1.setUserId(1);
		bid1.setItemId(1);
		
		
		BididingDetails bid2 = new BididingDetails();
		bid1.setBiddingId(2);
		bid1.setTime(Instant.now());
		bid1.setUserId(2);
		bid1.setItemId(1);
		
		bids.put(Integer.valueOf(1), bid1);
		bids.put(Integer.valueOf(2), bid2);
	}
	
	
}
