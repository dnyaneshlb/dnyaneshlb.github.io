package test.com.vuclip.biddingapp;

import org.junit.Test;

public class UserServiceImplTest {
	public void bidTest(){
		
	}
}
